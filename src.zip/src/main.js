// import firebase from 'firebase'
import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import mobileStyle from './mobileStyle.css'
import style from './styles.css'
import * as firebase from 'firebase/app'

Vue.config.productionTip = false

import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs, getDoc, get, addDoc, updateDoc, doc, where } from 'firebase/firestore/lite';
import { getStorage,ref,uploadString  } from "firebase/storage";
const firebaseConfig = {
  apiKey: "AIzaSyDmm5iHkIMjlLAGNednfTIJY43R0pcgm34",
  authDomain: "digital-flip-01.firebaseapp.com",
  projectId: "digital-flip-01",
  storageBucket: "digital-flip-01.appspot.com",
  messagingSenderId: "897533194463",
  appId: "1:897533194463:web:5a66a57ecf668ccd22796a",
  measurementId: "G-C424N257QH"
};
firebase.initializeApp(firebaseConfig)
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const storage = getStorage(app);

Vue.mixin({
  data: function () {
    return {
      db:db,
      collection:collection,
      getDocs:getDocs,
      get: get,
      getDoc: getDoc,
      addDoc:addDoc,
      updateDoc:updateDoc,
      doc:doc,
      where: where,
      storage:storage,
      ref:ref,
      uploadString :uploadString 
    }
  }
})

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
