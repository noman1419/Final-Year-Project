<template>
<div class="popup" id="popup">
    <div class="popup-contanier" id="popup-container">
            <div class="close-btn" @click="closeTask()">x</div>
        <form v-on:submit="createTask" class="popup-container">
            <div class="tx-popup">
                <p>Add Tasks</p>
            </div>
            <div class="inpt-popup">
                <input type="text" v-model="heading" placeholder="Name of Group">
                <input type="text" v-model="description" placeholder="Description">
            </div>
            <div class="info-popup">
                <div class="left-info">
                    <img src="../assets/rocket.png" alt="rocket">
                    <div class="info-popup-tx">
                        <p>Project</p>
                        <p>Welcome to PP</p>
                    </div>
                </div>
                <div class="right-info">
                    <svg width="100%" height="100%" viewBox="0 0 24 24"><path fill="currentColor" fill-rule="evenodd" d="M7.783 2.024a1 1 0 0 1 1.193.76l3.168 14.255 1.684-5.614A2 2 0 0 1 15.744 10h1.427a3.001 3.001 0 1 1 0 2h-1.427l-2.786 9.287a1 1 0 0 1-1.934-.07L7.807 6.74l-1.63 4.891A2 2 0 0 1 4.279 13H1a1 1 0 0 1 0-2h3.28L7.05 2.684a1 1 0 0 1 .732-.66zM20 10a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"></path></svg>
                    <div class="info-popup-tx">
                        <p>Section</p>
                        <p>In Progress</p>
                    </div>
                </div>
            </div>
            <div class="btn-popup">
                <button type="submit" class="popup-btn">Create Task</button>
            </div>
        </form>
    </div>
</div>
</template>
<script>
export default {
    props: {
        msg: String
    },
    data(){
        return{
            heading: '',
            description: '',
            task_id: null,
        }
    },
    components:{},
    watch: {
        "$route.params": {
        handler(newValue, preValue) {
              this.init()
        },  
        immediate: true
        }
    },
    created(){
        this.init()
    },
    methods: {
        init(){
            // console.log('init')
            if(this.$route.params.id){
                this.route_id = this.$route.params.id
                // console.log(this.route_id, 'this.router.param.id')
            }
        },
        closeTask(){
            document.getElementById('popup').classList.remove("showNewTaskPopup")
        },
        async createTask(e){
            e.preventDefault()
            // console.log(this.heading, this.description, 'userInfo')
            // alert(1)
            try{
                if(this.$route.params.id){
                    this.route_id = this.$route.params.id
                    // console.log(this.route_id, 'this.router.param.id')
                } 
                if(this.route_id){
                    this.$data.addDoc(this.$data.collection(this.$data.db, "project"), {
                        heading: this.heading,
                        description: this.description,
                        project_name: this.route_id,
                        status: 'Pending'
                    }).then(res =>{
                        // console.log(res, 'res')
                        this.task_id = res.id
                        this.closeTask()
                    })
                } else{
                    this.$data.addDoc(this.$data.collection(this.$data.db, "project"), {
                        heading: this.heading,
                        description: this.description,
                        status: 'Pending'
                    }).then(res =>{
                        // console.log(res, 'res')
                        this.task_id = res.id
                        this.closeTask()
                    })
                }
            }catch(e){
                console.log('Error occur ', e)
            }
        }
    },
}
</script>