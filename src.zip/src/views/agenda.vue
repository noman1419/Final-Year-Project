<template>
    <div class="project project-contianer agenda-body">
        <div class="white-contianer">
            <div class="a-contianer">
                <p>Due Today</p>
            </div>
            <div class="card-container advance-body">
                <div class="card-display" style="width: 100%;">
                    <div class="card" v-for="(itm, ind) in today_data" :key="ind" v-if="!loading && today_data.length">
                        <div class="card-body no-header">
                            <p class="card-heading">{{itm.heading}}</p>
                            <p class="card-descrition">{{itm.description}}</p>
                            <p class="card-date" v-if="itm.due_date"><span><svg width="100%" height="100%" viewBox="0 0 20 20"><g fill="none" fill-rule="evenodd"><circle cx="10" cy="10" r="10" fill="currentColor" opacity=".205"></circle><rect width="11" height="10" x="4.5" y="5.5" stroke="currentColor" rx="2"></rect><path fill="currentColor" d="M13.499 5A2.498 2.498 0 0 1 16 7.51V8H4v-.49A2.511 2.511 0 0 1 6.501 5h6.998z"></path><circle cx="7" cy="10" r="1" fill="currentColor"></circle><circle cx="10" cy="10" r="1" fill="currentColor"></circle><circle cx="13" cy="10" r="1" fill="currentColor"></circle><circle cx="7" cy="13" r="1" fill="currentColor"></circle><circle cx="10" cy="13" r="1" fill="currentColor"></circle><circle cx="13" cy="13" r="1" fill="currentColor"></circle><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" d="M6.5 4.5v2M13.5 4.5v2"></path></g></svg></span> 
                            {{itm.due_date}}</p>
                            <div class="card-footer">
                                <button class="basic card-button" v-for="(tag, i) in itm.tags" :key="i">{{tag}}</button>
                            </div>
                        </div>
                    </div>
                    <div style="text-align: center; margin-top: 30px" v-if="!loading && today_data.length == 0">
                        No Data
                    </div>
                </div>
            </div>

        </div>
        <div class="white-contianer">
            <div class="a-contianer">
                <p>Focus</p>
            </div>
            <div class="card-container advance-body">
                <div class="card-display" style="width: 100%;">
                    <div class="card" v-for="(itm, ind) in data" :key="ind">
                        <div class="card-body no-header">
                            <p class="card-heading">{{itm.heading}}</p>
                            <p class="card-descrition">{{itm.description}}</p>
                            <p class="card-date" v-if="itm.due_date"><span><svg width="100%" height="100%" viewBox="0 0 20 20"><g fill="none" fill-rule="evenodd"><circle cx="10" cy="10" r="10" fill="currentColor" opacity=".205"></circle><rect width="11" height="10" x="4.5" y="5.5" stroke="currentColor" rx="2"></rect><path fill="currentColor" d="M13.499 5A2.498 2.498 0 0 1 16 7.51V8H4v-.49A2.511 2.511 0 0 1 6.501 5h6.998z"></path><circle cx="7" cy="10" r="1" fill="currentColor"></circle><circle cx="10" cy="10" r="1" fill="currentColor"></circle><circle cx="13" cy="10" r="1" fill="currentColor"></circle><circle cx="7" cy="13" r="1" fill="currentColor"></circle><circle cx="10" cy="13" r="1" fill="currentColor"></circle><circle cx="13" cy="13" r="1" fill="currentColor"></circle><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" d="M6.5 4.5v2M13.5 4.5v2"></path></g></svg></span> {{itm.due_date}}</p>
                            <div class="card-footer">
                                <button class="basic card-button" v-for="(tag, i) in itm.tags" :key="i">{{tag}}</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="meeting noMobile">
            <div class="meeting-calender">
                <div class="meetingcalender">
                    <p href="#calender">Meeting Calender</p>
                    <div class="height-meeting">

                    </div>
                </div>
            </div>
            <div class="meeting-chart">
                <div class="meetingchart">
                    <p href="#chahrt">Meeting Chart</p>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import moment from 'moment'
import sideBar from '../components/sideBar.vue'
import topBar from '../components/topNavigation.vue'
import newTask from '../components/newTaskPopup.vue'
export default {
    components: { sideBar, topBar, newTask },
    created(){
        this.init()
    },
    data(){
        return{
            today_data: [],
            data: [],
            remain_data: [],
            loading: false
        }
    },
    methods:{
        async init(){
            var toDay = moment().format('YYYY-MM-DD')
            // console.log(toDay, 'toDay')
            this.loading = true
            if(this.$route.params.id){
                this.route_id = this.$route.params.id
                // console.log(this.$route.params.id, 'this.router.param.id')
            }
            try{
                const decRef = await this.$data.getDocs(this.$data.collection(this.$data.db, "project"))
                .then((res)=>{
                    let data = []
                    var count = 0
                    res.docs.forEach((doc) =>{
                        data.push({...doc.data(), id: doc.id})
                    })
                    // console.log(data, 'res data')
                    var d = []
                    var b = []
                    for(var i in data){
                        if(data[i] && data[i].due_date && data[i].due_date == toDay){
                            // console.log(data[i].due_date, 'due_date')
                            d.push(data[i])
                        } else{
                            b.push(data[i])
                        }
                    }
                    this.today_data = d
                    this.data = b
                    this.loading = false
                    // console.log(this.data, 'data')
                    // console.log(this.today_data, 'todaydata')
                })
            }catch(e){
                console.error("Error adding document: ", e)
            }
        },
    }
}
</script>

<style>
.agenda-body .a-contianer{
    justify-content: center;
}
.agenda-body .a-contianer p{
    color: #2d3748;
}
.agenda-body .card-container{
    height: calc(100% - 51px);
}
</style>