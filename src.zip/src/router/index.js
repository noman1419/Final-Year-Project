import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import app from '../views/app.vue'
import dashboard from '../views/dashboard.vue'
import agenda from '../views/agenda.vue'
import reports from '../views/reports.vue'
import projects from '../views/projects.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/about',
    name: 'About',
    component: () => import( '../views/About.vue')
  },
  {
    path: '/contact',
    name: 'contact',
    component: () => import( '../views/contact.vue')
  },
  {
    path: '/signup',
    name: 'signup',
    component: () => import( '../views/signup.vue')
  },
  {
    path: '/signin',
    name: 'signin',
    component: () => import( '../views/signin.vue')
  },
  {
    path: '/dashboard',
    name: 'dashboard',
    redirect: '/app/dashboard',
    component: dashboard
  },
  {
    path: '/agenda',
    name: 'agenda',
    redirect: '/app/agenda',
    component: agenda
  },
  {
    path: '/reports',
    name: 'reports',
    redirect: '/app/reports',
    component: reports
  },
  {
    path: '/projects',
    name: 'projects',
    redirect: '/app/projects',
    component: projects
  },
  {
    path: '/app',
    name: 'app',
    component: app,
    children:[{
      path: '/app/dashboard',
      name: 'dashboard',
      components: {app: dashboard}
    },{
      path: '/app/agenda',
      name: 'agenda',
      components: {app: agenda}
    },{
      path: '/app/reports',
      name: 'reports',
      components: {app: reports}
    },{
      path: '/app/projects',
      name: 'projects',
      components: {app: projects}
    },{
      path: '/app/projects/:id',
      name: 'projects',
      components: {app: projects}
    }]
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
