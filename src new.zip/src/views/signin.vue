<template>
  <div class="home">
    <div class="wizard">
        <div class="left">
            <div class="wizard-container">
                <div class="logo">
                    <img src="../assets/DigitalFlip.png" alt="">
                </div>
                <p class="">Discover Amazing Reputation with great build tools</p>
            </div>
        </div>
        <div class="right">
            <div class="wizard-container">
                <h2 class="heading">Login</h2>
                <p class="description">Enter your details to login your account</p>
                <div class="step">
                    <form v-on:submit="signin" class="signup-from">
                        <p class="error" v-if="error">Invalid Email & Password</p>
                        <input type="text" v-model="userInfo.email" class="input-field" placeholder="email">
                        <input type="password" v-model="userInfo.password" class="input-field" placeholder="password">
                        <div class="btn-conatiner">
                            <!-- <div></div> -->
                            <button id="signup-btn" type="submit">Login</button>
                        </div>
                        <router-link to="signup" class="signin_route" >Don't have an account? <span class="color-blue"> Signup</span></router-link>
                    </form>
                </div>
                
            </div>
        </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
    name: "Home",
    components: {
    },
    data() {
        return {
            userInfo: {
                type: 'Admin'
            },
            loading: false,
            error: false
        };
    },
    methods: {
        async signin(e){
            e.preventDefault()
            var user = {}
            // console.log(this.userInfo, 'userInfo')
            document.getElementById("signup-btn").disabled = true
            document.getElementById('signup-btn').innerHTML = 'Login...'
            this.loading = true
            try {
                const decRef = await this.$data.getDocs(this.$data.collection(this.$data.db, "user"))
                .then((res)=>{
                    let data = []
                    var count = 0
                    res.docs.forEach((doc) =>{
                        data.push({...doc.data(), id: doc.id})
                    })
                    // console.log(data, 'res data')
                    for(var i in data){
                        // console.log(data[i].email, this.userInfo.email, 'data[i]')
                        if(data[i].email == this.userInfo.email){
                            count++
                            // console.log(count, 'for if')
                            user = data[i]
                            this.error = true
                            document.getElementById("signup-btn").disabled = false
                            document.getElementById('signup-btn').innerHTML = 'Login'
                        }
                    }
                    if(count != 0){
                        // console.log(user, 'for else')
                        this.error = false
                        // this.$data.addDoc(this.$data.collection(this.$data.db, "user"), {
                        //     email: this.userInfo.email,
                        //     password: this.userInfo.password
                        // }).then(res=>{
                        //     this.loading = false
                        //     this.userInfo.id = res.id
                        // });
                        this.userInfo = user
                        localStorage.setItem('userInfo', JSON.stringify(this.userInfo))
                        // this.closeSignup()
                        this.$router.push({path:'/dashboard'});
                    } else{
                        this.error = true
                        document.getElementById("signup-btn").disabled = false
                        document.getElementById('signup-btn').innerHTML = 'Login'
                    }
                })     
            }catch(e){
                console.error("Error adding document: ", e)
            }
            // e.preventDefault()
            // console.log(this.$data.db, 'db')
            // try {
            //     const decRef = await this.$data.addDoc(this.$data.collection(this.$data.db, "user"), {
            //         name: this.userInfo.name,
            //         email: this.userInfo.email,
            //         password: this.userInfo.password
            //     });
            //     this.loading = false
            //     this.user.id = decRef.id
            //     localStorage.setItem('userInfo', JSON.stringify(this.userInfo))
            //     this.$router.push({path:'/app/dashboard'});
            // }catch(e){
            //     console.error("Error adding document: ", e)
            // }
        }
    }
  
};
</script>

<style scoped>
h1, h2, h3, h4, h5, h6, p{
    margin: 0;
}
.wizard{
    height: 100vh;
    display: flex;
}
.wizard .right{
    width: 60%;
}
.wizard .left{
    width: 40%;
    background: #2d3748;
    color: #fbfbfe;
}
.wizard .left .wizard-container{
    width: 80%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    text-align: center;
}
.logo{
    text-align: center;
}
.logo img{
    width: 70%;
}
.wizard .left .wizard-container p{
    font-size: 18px;
    line-height: 28px;
    letter-spacing: 1px;
}
.wizard-container{
    height: calc(100vh - 180px);
    width: 65%;
    margin: 90px auto;
}
.wizard-container .heading{
    /* text-align: center; */
    font-size: 34px;
    line-height: 44px;
}
.wizard-container .description{
    /* text-align: center; */
    font-size: 18px;
    line-height: 28px;
}
.signup-from{
    display: flex;
    flex-direction: column;
    margin-top: 80px;
}
.signup-from .input-field{
    padding: 20px;
    margin-bottom: 20px;
    font-size: 16px;
    border-radius: 8px;
    border: none;
    background: #eef2f7;
    box-shadow: 0 1px 2px 1px #2d374838;
}
.signup-from .btn-conatiner{
    display: flex;
    justify-content: space-between;
}
.signup-from button{
    padding: 20px;
    font-size: 16px;
    border-radius: 8px;
    border: none;
    box-shadow: 0 1px 2px 1px #2d374838;
    background: #2d3748;
    color: #fbfbf9;
    min-width: 135px;
}
select:focus{
    outline: none;
}
.error{
    color: #d20404;
    text-align: center;
    margin-bottom: 10px;
    font-size: 14px;
}
.signin_route{
    margin-top: 10px;
}
.signin_route .color-blue{
    color: #0af;
}
</style>
