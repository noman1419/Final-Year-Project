<template>
    <div class="container">
        <sideBar/>
        <topNavigation/>
          <div class="content">
            <!-- <button @click="getUser">Get User</button> -->
            <h2 class="small-heading">Good Evening, {{capCase(userInfo.name)}}</h2>
            <h1 class="heading" id="time">{{currentTime}}</h1>
            <div class="discription">
              “The difference between ordinary and extraordinary is that little
              extra.”
            </div>
            <div class="author">JIMMY JOHNSON</div>
          </div>
        </div>
</template>
<script>
import sideBar from '@/components/sideBar.vue'
import topNavigation from '@/components/topNavigation.vue'
import axios from 'axios'

export default {
    data(){
        return{
            currentTime: '',
            userInfo: {}
        }
    },
    components:{
        sideBar,
        topNavigation
    },
    created(){
        this.time(),
        this.init()
    },
    methods:{
        time(){
            // console.log('hell')
            var d = new Date();
            var m = d.getMinutes();
            var h = d.getHours();
            let ampm = h >= 12 ? 'PM' : 'AM';
            h = h % 12;
            h = h ? h : 12;
            m = m.toString().padStart(2, '0');
            this.currentTime = h + ':' + m + ' ' + ampm;
            // console.log(this.currentTime)
        },
        init(){
            this.userInfo = JSON.parse(localStorage.getItem("userInfo"));
        },
        capCase(string) {
            return string.charAt(0).toUpperCase() + string.slice(1);
        },
        trimname(string){
            return string.charAt(0).toUpperCase()
        },
        getUser(){
            // var filters = [{
            //         match_phrase: {
            //             event: obj.event
            //         }
            //     },
            //     {
            //         match_phrase: {
            //             email: obj.email
            //         }
            //     }
            // ]
            axios.get( "http://localhost:4000/_/user/_search", {
                    from: 0,
                    size: 5000,
                }).then(response => {
                // console.log(response)
            })
            // this.$store.dispatch("SignIn", this.userInfo).then(response => {
            //     setTimeout(() => {
            //         if(!this.$store.state.error){
            //             this.closeSigninPop()
            //             this.$router.push({path:'/account/profile'})
            //         }
            //         else{
            //             this.error = true
            //         }
            //      }, 500);
            // })
        }

    }
    
}
</script>